require 'rails_helper'

RSpec.describe "SoccerRates", type: :request do

end
